
# -*- coding: utf-8 -*-

import os

from qgis.PyQt.QtWidgets import QAction
from qgis.PyQt.QtGui import QIcon
from .dialog import ServidaoGISDialog


class ServidaoGIS:

    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.dialog = None

    def initGui(self):

        icon_path = os.path.join(
            os.path.dirname(__file__),
            'resources',
            'icon.svg'
        )

        self.action = QAction(
            QIcon(icon_path),
            "Servidão GIS",
            self.iface.mainWindow()
        )

        self.action.triggered.connect(self.run)

        self.iface.addPluginToMenu("&Servidão GIS", self.action)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        if self.action:
            self.iface.removePluginMenu("&Servidão GIS", self.action)
            self.iface.removeToolBarIcon(self.action)
            self.action = None

    def run(self):
        if self.dialog is None:
            self.dialog = ServidaoGISDialog(self.iface)

        self.dialog.show()
        self.dialog.raise_()
        self.dialog.activateWindow()
